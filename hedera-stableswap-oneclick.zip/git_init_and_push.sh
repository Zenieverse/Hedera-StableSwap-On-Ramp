#!/usr/bin/env bash
# Initialize a git repo, commit files, create GitHub repo via GH CLI, and push to origin
# Prereqs: git, gh (GitHub CLI) installed and authenticated (gh auth login)
set -e
REPO_NAME=${1:-hedera-stableswap}
GH_VISIBILITY=${2:-private} # public or private
echo "Initializing git repo and pushing to GitHub as ${REPO_NAME} (${GH_VISIBILITY})"
git init
git add .
git commit -m "Initial commit - Hedera StableSwap"
gh repo create "$REPO_NAME" --"$GH_VISIBILITY" --source=. --remote=origin --push
echo "Repository created and pushed: https://github.com/$(gh repo view --json nameWithOwner -q .nameWithOwner)"

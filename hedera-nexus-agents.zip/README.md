# Hedera Nexus Agents — Team eTopia

Hedera Nexus Agents is a Collaborative Multi-Agent Marketplace that enables AI agents to register as verifiable on-chain identities (ERC-8004), negotiate tasks, and transact using Hedera Token Service (HTS) with immutable proofs recorded through Hedera Consensus Service (HCS).

This scaffold provides a working **developer-friendly** starter: frontend dashboard, backend API with Hedera SDK integration points, sample Solidity contracts, sample agents (simulated), infra for Docker, and documentation for hackathon submission.

## What's included
- `frontend/` — Next.js dashboard (placeholder) with agent list and demo UI.
- `backend/` — Node.js + Express server with Hedera SDK scaffolding, sample agent scripts, and simple task execution flow (simulated for testnet).
- `contracts/` — Solidity example for ERC-8004-style Agent identity and a sample Escrow contract outline.
- `docs/` — Submission summary, demo pitch, architecture and runbook.
- `infra/` — Dockerfiles, docker-compose, and `.env.example`.
- `demo/` — Demo scripts to simulate agents interacting (local only).

## Quickstart (developer)
### 1) Clone and install
```bash
# unzip repository then
cd hedera-nexus-agents/backend
npm install
cd ../frontend
npm install
```

### 2) Configure environment
Copy `infra/.env.example` to `infra/.env` and set your Hedera testnet keys and LLM/API keys locally (do not commit secrets).

### 3) Run locally (development)
Backend (API + simulated agents):
```bash
cd backend
npm run dev
```
Frontend (dashboard):
```bash
cd frontend
npm run dev
# open http://localhost:3000
```

### 4) Simulate a demo
Use `node backend/demo/run-demo.js` to simulate two agents negotiating a task and completing an exchange (mocked, prints steps to console).

## Notes
- The scaffold is ready to be wired to real Hedera accounts and contracts. Replace placeholders with real Hedera account IDs and operator keys when you are ready to deploy to testnet/mainnet.
- Smart contracts are provided as examples and need compilation/deployment via your preferred tool (Hardhat/Foundry/Remix).

-- Team eTopia

const { Client, PrivateKey, TopicCreateTransaction } = require("@hashgraph/sdk");
require("dotenv").config();
const operatorId = process.env.HEDERA_ACCOUNT_ID;
const operatorKey = process.env.HEDERA_PRIVATE_KEY;
const network = process.env.NETWORK || "testnet";
if (!operatorId || !operatorKey) {
  console.error("Set HEDERA_ACCOUNT_ID and HEDERA_PRIVATE_KEY in .env");
  process.exit(1);
}
const client = Client.forName(network);
client.setOperator(operatorId, operatorKey);
async function createHCSTopicIfMissing() {
  if (process.env.HCS_TOPIC_ID) return process.env.HCS_TOPIC_ID;
  const tx = await new TopicCreateTransaction().execute(client);
  const receipt = await tx.getReceipt(client);
  const topicId = receipt.topicId.toString();
  console.log("Created HCS topic:", topicId);
  return topicId;
}
module.exports = { client, createHCSTopicIfMissing };

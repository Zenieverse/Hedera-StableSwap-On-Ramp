const express = require("express");
const bodyParser = require("body-parser");
const fetch = require("node-fetch");
const { createStableToken, mintStableToken } = require("./stableToken");
const { createPool, executeSwap, getAmountOut, pools } = require("./poolManager");
const { createHCSTopicIfMissing, client } = require("./hederaClient");
const { TopicMessageSubmitTransaction, TransferTransaction, TokenId, Hbar, PrivateKey } = require("@hashgraph/sdk");
const { Pool } = require('pg');
require("dotenv").config();
const app = express();
app.use(bodyParser.json());
const MIRROR_NODE = process.env.MIRROR_NODE || "https://testnet.mirrornode.hedera.com/api/v1";
const TREASURY = process.env.TREASURY_ACCOUNT;
const PLATFORM_TREASURY = process.env.PLATFORM_TREASURY || TREASURY;
const POSTGRES_URL = process.env.POSTGRES_URL || 'postgresql://postgres:postgres@localhost:5432/stableswap';
const pgPool = new Pool({ connectionString: POSTGRES_URL });
async function ensurePoolInDb(poolId, tokenA, tokenB, reserveA, reserveB) {
  const res = await pgPool.query('SELECT id FROM pools WHERE id=$1', [poolId]);
  if (res.rowCount === 0) {
    await pgPool.query('INSERT INTO pools(id, token_a, token_b, reserve_a, reserve_b) VALUES($1,$2,$3,$4,$5)', [poolId, tokenA, tokenB, reserveA.toString(), reserveB.toString()]);
  }
}
async function updatePoolReserves(poolId, reserveA, reserveB) {
  await pgPool.query('UPDATE pools SET reserve_a=$2, reserve_b=$3 WHERE id=$1', [poolId, reserveA.toString(), reserveB.toString()]);
}
async function markTxProcessed(txId) {
  await pgPool.query('INSERT INTO processed_txs(transaction_id) VALUES($1) ON CONFLICT DO NOTHING', [txId]);
}
async function isTxProcessed(txId) {
  const r = await pgPool.query('SELECT transaction_id FROM processed_txs WHERE transaction_id=$1', [txId]);
  return r.rowCount > 0;
}
let poolCounter = 0;
let topicId = process.env.HCS_TOPIC_ID;
async function logEvent(obj) {
  if (!topicId) topicId = await createHCSTopicIfMissing();
  const tx = new TopicMessageSubmitTransaction({ topicId, message: JSON.stringify(obj) });
  await tx.execute(client);
}
app.post("/create-stable", async (req, res) => {
  try {
    const tokenId = await createStableToken(req.body);
    await logEvent({ type: "create-stable", tokenId });
    res.json({ tokenId });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post("/mint", async (req, res) => {
  try {
    const receipt = await mintStableToken(req.body.tokenId, req.body.amount);
    await logEvent({ type: "mint", ...req.body });
    res.json({ receipt });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post("/create-pool", async (req, res) => {
  try {
    const poolId = req.body.poolId || ("pool-" + (++poolCounter));
    createPool(poolId, req.body.tokenAId, req.body.tokenBId, req.body.reserveA, req.body.reserveB);
    await ensurePoolInDb(poolId, req.body.tokenAId, req.body.tokenBId, req.body.reserveA, req.body.reserveB);
    await logEvent({ type: "create-pool", poolId, tokenAId: req.body.tokenAId, tokenBId: req.body.tokenBId });
    res.json({ poolId });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
// Estimate endpoint
app.get("/estimate", async (req, res) => {
  try {
    const { from, to, amountHuman, decimals } = req.query;
    const poolEntry = Object.entries(pools).find(([k,p])=> (p.tokenAId===from && p.tokenBId===to) || (p.tokenAId===to && p.tokenBId===from));
    if (!poolEntry) return res.status(400).json({ error: "Pool not found for requested pair" });
    const [poolId, pool] = poolEntry;
    const dec = Number(decimals || 2);
    // compute using big.js in poolManager getAmountOut for accuracy
    const amountSmall = (Number(amountHuman) * (10**dec)).toString();
    const isAtoB = pool.tokenAId === from;
    const reserveIn = isAtoB ? pool.reserveA : pool.reserveB;
    const reserveOut = isAtoB ? pool.reserveB : pool.reserveA;
    const dy = getAmountOut(amountSmall, reserveIn, reserveOut);
    const estHuman = Number(dy) / (10**dec);
    res.json({ estimatedOutHuman: estHuman.toString() });
  } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
});
// Build unsigned transfer bytes for wallet signing
app.post("/build-user-transfer", async (req, res) => {
  try {
    const { userAccountId, tokenId, amount, memo } = req.body;
    if (!userAccountId || !tokenId || !amount) return res.status(400).json({ error: "Missing fields" });
    if (!TREASURY) return res.status(500).json({ error: "Server TREASURY_ACCOUNT not set" });
    const transferTx = new TransferTransaction()
      .addTokenTransfer(TokenId.fromString(tokenId), userAccountId, -Number(amount))
      .addTokenTransfer(TokenId.fromString(tokenId), TREASURY, Number(amount))
      .setTransactionMemo(memo || "");
    // Freeze with client to build transaction bytes but do NOT sign
    const frozen = await transferTx.freezeWith(client);
    const bytes = frozen.toBytes(); // unsigned bytes
    const b64 = Buffer.from(bytes).toString('base64');
    res.json({ unsignedTxBase64: b64, note: "Unsigned, frozen transfer tx bytes to be signed by user's wallet" });
  } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
});
// Custodial swap (operator executes) for testing
app.post("/swap", async (req, res) => {
  try {
    const { poolId, fromTokenId, toTokenId, amountIn, userAccountId } = req.body;
    const result = await executeSwap(poolId, fromTokenId, toTokenId, amountIn, userAccountId);
    await logEvent({ type: "swap", poolId, fromTokenId, toTokenId, amountIn, userAccountId, amountOut: result.amountOut });
    // persist updated reserves to DB
    await updatePoolReserves(poolId, pools[poolId].reserveA, pools[poolId].reserveB);
    res.json({ result });
  } catch (e) { console.error(e); res.status(500).json({ error: e.message }); }
});
app.post("/fiat-webhook", async (req, res) => {
  try {
    const { userId, currency, amount, reference } = req.body;
    await logEvent({ type: "fiat_deposit", userId, currency, amount, reference });
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ ok: false, error: e.message }); }
});
// Mirror Node watcher with Postgres persistence for processed txs & pool updates
const POLL_INTERVAL = Number(process.env.WATCHER_POLL_MS || 8000);
let lastPollTs = Date.now() - 60*1000;
async function pollMirrorNodeAndProcess() {
  if (!TREASURY) return;
  try {
    const url = `${MIRROR_NODE}/transactions?account.id=${encodeURIComponent(TREASURY)}&order=desc&limit=25`;
    const resp = await fetch(url);
    if (!resp.ok) { console.warn('Mirror node fetch failed', resp.status); return; }
    const js = await resp.json();
    const txs = js.transactions || [];
    for (const tx of txs) {
      if (await isTxProcessed(tx.transaction_id)) continue;
      const tsMillis = new Date(tx.consensus_timestamp).getTime();
      if (tsMillis <= lastPollTs) continue;
      let memo = null;
      try { if (tx.memoBase64) memo = Buffer.from(tx.memoBase64, 'base64').toString('utf8'); } catch(e){ memo = null; }
      if (memo && memo.includes('swap_intent')) {
        try {
          const intent = JSON.parse(memo);
          const tokenTransfers = tx.token_transfers || [];
          const treasuryTransfer = tokenTransfers.find(t => t.token_id === intent.from && Number(t.amount) > 0 && t.account === TREASURY);
          if (treasuryTransfer) {
            const poolEntry = Object.entries(pools).find(([k,p])=> (p.tokenAId===intent.from && p.tokenBId===intent.to) || (p.tokenAId===intent.to && p.tokenBId===intent.from));
            if (!poolEntry) {
              await logEvent({ type: 'swap_error', reason: 'pool_not_found', tx: tx.transaction_id });
            } else {
              const [poolId, pool] = poolEntry;
              const amountInSmall = BigInt(Math.floor(Number(treasuryTransfer.amount)));
              const isAtoB = pool.tokenAId === intent.from;
              const reserveIn = BigInt(Math.floor(Number(isAtoB ? pool.reserveA : pool.reserveB)));
              const reserveOut = BigInt(Math.floor(Number(isAtoB ? pool.reserveB : pool.reserveA)));
              const feeNumerator = 997n;
              const feeDenominator = 1000n;
              const dxWithFee = amountInSmall * feeNumerator / feeDenominator;
              const numerator = dxWithFee * reserveOut;
              const denominator = reserveIn + dxWithFee;
              const dy = numerator / denominator;
              const userTransferEntry = tokenTransfers.find(t => t.token_id === intent.from && Number(t.amount) < 0);
              const userAccountId = userTransferEntry ? userTransferEntry.account : intent.userAccountId;
              if (!userAccountId) {
                await logEvent({ type: 'swap_error', reason: 'user_account_not_found', tx: tx.transaction_id });
              } else {
                // transfer dy of intent.to from TREASURY -> userAccountId
                const opKey = PrivateKey.fromString(process.env.HEDERA_PRIVATE_KEY);
                const transferTx = new TransferTransaction()
                  .addTokenTransfer(TokenId.fromString(intent.to), TREASURY, -Number(dy.toString()))
                  .addTokenTransfer(TokenId.fromString(intent.to), userAccountId, Number(dy.toString()))
                  .setTransactionMemo(`swap_finalized ${tx.transaction_id}`);
                const signed = await transferTx.freezeWith(client).sign(opKey);
                const respFinal = await signed.execute(client);
                const receiptFinal = await respFinal.getReceipt(client);
                // update in-memory pool and persist
                if (isAtoB) {
                  pool.reserveA = (BigInt(Math.floor(Number(pool.reserveA))) + amountInSmall).toString();
                  pool.reserveB = (BigInt(Math.floor(Number(pool.reserveB))) - dy).toString();
                } else {
                  pool.reserveB = (BigInt(Math.floor(Number(pool.reserveB))) + amountInSmall).toString();
                  pool.reserveA = (BigInt(Math.floor(Number(pool.reserveA))) - dy).toString();
                }
                await updatePoolReserves(poolId, pool.reserveA, pool.reserveB);
                await logEvent({ type: 'swap_finalized', tx: tx.transaction_id, poolId, amountIn: amountInSmall.toString(), amountOut: dy.toString(), user: userAccountId, receipt: receiptFinal });
              }
            }
          }
        } catch(e) {
          console.error('Failed to process swap_intent memo', e);
          await logEvent({ type: 'swap_error', reason: 'exception', error: e.message, tx: tx.transaction_id });
        }
      }
      await markTxProcessed(tx.transaction_id);
    }
    lastPollTs = Date.now();
  } catch (e) {
    console.error('Watcher error', e);
  }
}
setInterval(pollMirrorNodeAndProcess, Number(process.env.WATCHER_POLL_MS || 8000));
const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Server started on port ${port}. Mirror Node watcher polling every ${process.env.WATCHER_POLL_MS || 8000}ms`);
});

module.exports = app;

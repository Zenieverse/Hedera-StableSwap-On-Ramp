export const BACKEND_API = process.env.BACKEND_API || "http://localhost:3000";
export const MIRROR_NODE = "https://testnet.mirrornode.hedera.com/api/v1";
export const TREASURY_ACCOUNT = process.env.TREASURY_ACCOUNT || "0.0.12345"; // update to your backend treasury account

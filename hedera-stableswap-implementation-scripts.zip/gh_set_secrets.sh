#!/usr/bin/env bash
# Set GitHub repository secrets using gh CLI
# Usage: ./gh_set_secrets.sh <REPO> (e.g. youruser/hedera-stableswap)
# Prereqs: gh authenticated with permission to set secrets
set -e
if [ -z "$1" ]; then echo "Usage: $0 owner/repo"; exit 1; fi
REPO=$1
echo "Setting recommended secrets on $REPO (you will be prompted to enter values)"
read -p "POSTGRES_URL: " POSTGRES_URL
read -p "RENDER_API_KEY: " RENDER_API_KEY
read -p "RENDER_SERVICE_ID: " RENDER_SERVICE_ID
read -p "HEDERA_ACCOUNT_ID: " HEDERA_ACCOUNT_ID
read -s -p "HEDERA_PRIVATE_KEY (paste, will be hidden): " HEDERA_PRIVATE_KEY; echo
read -p "TREASURY_ACCOUNT: " TREASURY_ACCOUNT
gh secret set POSTGRES_URL --body "$POSTGRES_URL" --repo "$REPO"
gh secret set RENDER_API_KEY --body "$RENDER_API_KEY" --repo "$REPO"
gh secret set RENDER_SERVICE_ID --body "$RENDER_SERVICE_ID" --repo "$REPO"
gh secret set HEDERA_ACCOUNT_ID --body "$HEDERA_ACCOUNT_ID" --repo "$REPO"
gh secret set HEDERA_PRIVATE_KEY --body "$HEDERA_PRIVATE_KEY" --repo "$REPO"
gh secret set TREASURY_ACCOUNT --body "$TREASURY_ACCOUNT" --repo "$REPO"
echo "Secrets set."

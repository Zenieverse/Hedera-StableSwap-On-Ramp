// migrate.js - creates tables: pools, processed_txs
const { Client } = require('pg');
require('dotenv').config();
async function migrate() {
  const client = new Client({ connectionString: process.env.POSTGRES_URL });
  await client.connect();
  await client.query(`
    CREATE TABLE IF NOT EXISTS pools (
      id TEXT PRIMARY KEY,
      token_a TEXT NOT NULL,
      token_b TEXT NOT NULL,
      reserve_a NUMERIC NOT NULL,
      reserve_b NUMERIC NOT NULL,
      created_at TIMESTAMP DEFAULT now()
    );
  `);
  await client.query(`
    CREATE TABLE IF NOT EXISTS processed_txs (
      transaction_id TEXT PRIMARY KEY,
      processed_at TIMESTAMP DEFAULT now()
    );
  `);
  console.log('Migration complete');
  await client.end();
}
migrate().catch(e => { console.error(e); process.exit(1); });

#!/usr/bin/env bash
# Deploy to Render: push code to GitHub, connect service in Render dashboard using render.yaml
echo "1) Commit and push this repo to GitHub: git init && git add . && git commit -m 'deploy' && git remote add origin <your-repo> && git push -u origin main"
echo "2) In Render dashboard, create a new service using 'Deploy from Git' and import render.yaml from the repo root."
echo "3) Configure the secret environment variables in Render (HEDERA_PRIVATE_KEY, HEDERA_ACCOUNT_ID, TREASURY_ACCOUNT, POSTGRES_URL)"
echo "4) Run migrations: in Render shell run: cd backend && npm run migrate"
echo "5) Visit frontend service URL and backend /health"

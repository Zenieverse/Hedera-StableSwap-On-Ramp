#!/usr/bin/env bash
# render_deploy_helper.sh
# This script uses the Render CLI to trigger a deployment. Install Render CLI: https://render.com/docs/cli
# Usage: RENDER_SERVICE_ID=svc_xxx RENDER_API_KEY=env_yyy ./render_deploy_helper.sh
set -e
if [ -z "$RENDER_SERVICE_ID" ] || [ -z "$RENDER_API_KEY" ]; then
  echo "Set RENDER_SERVICE_ID and RENDER_API_KEY environment variables."
  exit 1
fi
echo "Triggering Render deploy for service $RENDER_SERVICE_ID"
# The Render CLI uses personal API key from env RENDER_API_KEY
# If render CLI is installed and authenticated, you can trigger a deploy; otherwise instruct user.
if command -v render >/dev/null 2>&1; then
  render services redeploy $RENDER_SERVICE_ID --api-key $RENDER_API_KEY
else
  echo "Render CLI not found. Install from https://render.com/docs/cli and run the command above."
fi

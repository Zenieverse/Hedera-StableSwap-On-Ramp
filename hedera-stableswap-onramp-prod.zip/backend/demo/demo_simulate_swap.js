// demo_simulate_swap.js
// This script simulates a user performing a swap intent by building a transfer payload,
// signing it locally with a test account (for demo only), and submitting it to the Hedera testnet.
const fetch = require('node-fetch');
const { Client, TransferTransaction, PrivateKey } = require('@hashgraph/sdk');
require('dotenv').config();
(async ()=>{
  const backend = process.env.BACKEND_API || 'http://localhost:3000';
  const userKey = PrivateKey.fromString(process.env.DEMO_USER_PRIVATE_KEY);
  const userAccount = process.env.DEMO_USER_ACCOUNT;
  const treasury = process.env.TREASURY_ACCOUNT;
  const tokenId = process.env.DEMO_TOKEN_ID;
  if(!userAccount || !userKey || !tokenId) return console.error('Set DEMO_USER_ACCOUNT, DEMO_USER_PRIVATE_KEY, DEMO_TOKEN_ID in .env');
  // 1) request build-user-transfer
  const memo = JSON.stringify({ type: 'swap_intent', from: tokenId, to: process.env.DEMO_TOKEN_OUT_ID, amountInSmall: '100', minOutHuman: '0' , userAccountId: userAccount });
  const resp = await fetch(backend + '/build-user-transfer', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ userAccountId: userAccount, tokenId: tokenId, amount: '100', memo }) });
  const js = await resp.json();
  if(!js.unsignedTxBase64) return console.error('No unsigned tx returned', js);
  const txBytes = Buffer.from(js.unsignedTxBase64, 'base64');
  // Sign locally (simulate user's wallet)
  const signed = require('@hashgraph/sdk').Transaction.fromBytes(txBytes).sign(userKey);
  const client = Client.forName(process.env.NETWORK || 'testnet');
  client.setOperator(process.env.HEDERA_ACCOUNT_ID, process.env.HEDERA_PRIVATE_KEY); // operator used to submit
  const submitResp = await signed.execute(client);
  const receipt = await submitResp.getReceipt(client);
  console.log('Submitted simulated user transfer tx, receipt:', receipt);
})().catch(e=>{ console.error(e); process.exit(1); });

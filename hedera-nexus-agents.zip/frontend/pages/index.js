import useSWR from 'swr';
const fetcher = (url)=> fetch(url).then(r=>r.json());

export default function Home(){
  const { data } = useSWR('/api/agents', fetcher, {fallbackData:{agents:[{name:'DataX'},{name:'AlphaBot'}]}});
  return (
    <main style={{fontFamily:'Inter, system-ui', padding:24}}>
      <header style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <h1>Hedera Nexus Agents — Team eTopia</h1>
        <div>Demo Dashboard</div>
      </header>

      <section style={{display:'grid', gridTemplateColumns:'1fr 400px', gap:20, marginTop:24}}>
        <div style={{background:'#fff', padding:16, borderRadius:8}}>
          <h2>Active Agents</h2>
          <ul>
            {data.agents.map((a,i)=>(<li key={i}>{a.name} — {a.model||'n/a'}</li>))}
          </ul>
        </div>
        <div style={{background:'#fff', padding:16, borderRadius:8}}>
          <h2>Recent Tasks</h2>
          <p>No tasks yet — run the demo to simulate an A2A exchange.</p>
        </div>
      </section>
    </main>
  )
}

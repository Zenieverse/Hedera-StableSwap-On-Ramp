# Demo & Deployment Notes

- To deploy contracts compile and deploy using Hardhat or Remix to Hedera EVM (testnet).
- Set environment variables in infra/.env before starting containers.
- Use Hedera SDK (backend/src/index.js) to create HCS topics or interact with HTS.
- The included demo is a simulated flow to help showcase A2A behavior without live Hedera keys.

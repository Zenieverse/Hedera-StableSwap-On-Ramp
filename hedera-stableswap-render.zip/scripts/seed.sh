#!/usr/bin/env bash
# Seed script to create demonstration token + pool via backend API
echo "Call backend /create-stable and /create-pool endpoints via curl or Postman to seed demo environment."

const request = require('supertest');
const app = require('../server'); // adjust export if needed
describe('API Sanity', ()=>{
  it('should 400 on estimate when pool missing', async ()=>{
    const res = await request('http://localhost:3000').get('/estimate?from=0.0.1&to=0.0.2&amountHuman=1&decimals=2');
    expect([200,400]).toContain(res.status); // allow either if server has pool
  });
});

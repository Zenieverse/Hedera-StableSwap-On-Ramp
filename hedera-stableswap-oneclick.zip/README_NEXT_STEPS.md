Next steps & checklist - What these scripts do and what you need to run
---------------------------------------------------------------------
1) Prepare environment:
   - Install prerequisites: git, gh (GitHub CLI), render CLI (optional), docker, node >=20, npm
   - Have GitHub account authenticated via gh auth login
   - Have Render account and API key (from Render dashboard) if you plan to deploy there

2) Push code to GitHub & configure secrets:
   - Run: ./git_init_and_push.sh your-repo-name
   - Then: ./gh_set_secrets.sh youruser/your-repo to add secrets used by GitHub Actions

3) Deploy to Render:
   - In Render dashboard, create services from render.yaml or connect the GitHub repo and allow Render to detect render.yaml
   - Add secrets in Render's dashboard (POSTGRES_URL, HEDERA_ACCOUNT_ID, HEDERA_PRIVATE_KEY secret, TREASURY_ACCOUNT)
   - Run migrations in Render shell: cd backend && npm run migrate
   - Optionally use render CLI or REST API to trigger redeploys (scripts provided)

4) Run demo locally (optional):
   - ./run_demo_locally.sh will start Postgres docker, run migrate, start backend, and run demo script (requires demo user keys)

5) Security reminder:
   - Use KMS/Secret Manager. Never paste private keys into public repos.
   - Rotate keys after testing.

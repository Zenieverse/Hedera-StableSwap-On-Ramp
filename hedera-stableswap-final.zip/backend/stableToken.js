const { TokenCreateTransaction, TokenMintTransaction, TokenSupplyType, Hbar, PrivateKey } = require('@hashgraph/sdk');
const { client } = require('./hederaClient');
require('dotenv').config();
async function createStableToken({ name, symbol, decimals=2, initialSupply=0 }){
  const operatorId = process.env.HEDERA_ACCOUNT_ID;
  const operatorKey = process.env.HEDERA_PRIVATE_KEY;
  const tx = await new TokenCreateTransaction().setTokenName(name).setTokenSymbol(symbol).setDecimals(decimals).setTreasuryAccountId(operatorId).setInitialSupply(initialSupply).setTokenSupplyType(TokenSupplyType.INFINITE).setMaxTransactionFee(new Hbar(2)).freezeWith(client);
  const key = PrivateKey.fromString(operatorKey); const signed = await tx.sign(key); const resp = await signed.execute(client); const receipt = await resp.getReceipt(client); return receipt.tokenId.toString();
}
async function mintStableToken(tokenId, amount){ const tx = await new TokenMintTransaction().setTokenId(tokenId).setAmount(amount).freezeWith(client); const key = PrivateKey.fromString(process.env.HEDERA_PRIVATE_KEY); const resp = await tx.sign(key).execute(client); return await resp.getReceipt(client); }
module.exports = { createStableToken, mintStableToken };

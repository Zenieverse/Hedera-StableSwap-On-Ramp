# Hedera StableSwap On-Ramp - Render Deployment Bundle
This bundle is pre-configured for deployment to **Render** (recommended) and targets **Hedera Testnet** by default.

## Contents
- backend/: Node.js backend with watcher (can run as worker)
- frontend/: simple Vite frontend scaffold (replace with full frontend-v2 if needed)
- render.yaml: Render services (web, worker, static)
- scripts/: deployment helper scripts
- migrate.js: creates Postgres schema

## Quick deploy (summary)
1. Push this repo to GitHub (private or public).
2. Create a new Render service and import this repo (select 'Deploy from Git' and Render will detect render.yaml).
3. In Render dashboard, add secret environment variables:
   - POSTGRES_URL (or create managed Postgres and set URL)
   - HEDERA_ACCOUNT_ID
   - HEDERA_PRIVATE_KEY (use Render secrets)
   - TREASURY_ACCOUNT
   - NETWORK (default: testnet)
4. After services build, run migrations on the backend (`cd backend && npm run migrate`).
5. Seed demo tokens via backend endpoints (`/create-stable`, `/mint`, `/create-pool`).
6. Configure frontend to call backend URL (update src/config.js if using full frontend-v2).

## Security notes
- **DO NOT** store private keys in source. Use Render Secrets and/or integrate with a KMS (AWS KMS / Hashicorp Vault).
- Use Render managed Postgres for persistent storage.
- Configure health checks and alerting in Render for uptime monitoring.

## Next steps
- Replace frontend/ with the full frontend-v2 zip (provided earlier) before deploying static service.
- Configure CI/CD with GitHub Actions if desired.


## CI/CD & GitHub Actions

A GitHub Actions workflow is included at `.github/workflows/ci-deploy.yml`. Configure `RENDER_API_KEY` and `RENDER_SERVICE_ID` in your repository secrets to enable automated deployments on pushes to `main`.

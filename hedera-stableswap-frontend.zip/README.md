# Hedera StableSwap Frontend Dashboard

This frontend demo connects to HashConnect (HashPack) and the Hedera Mirror Node to show liquidity and execute swaps via the backend API.

Features:
- Connect wallet via HashConnect (HashPack)
- Show token balances (Mirror Node)
- Swap form that calls backend `/swap` endpoint
- Simple liquidity chart (Mirror Node data)

Run:
1. `npm install`
2. Fill backend URL in `src/config.js` if needed
3. `npm start` (dev server via Vite)

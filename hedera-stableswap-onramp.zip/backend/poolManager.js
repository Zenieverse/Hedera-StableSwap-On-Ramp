const Big = require("big.js");
const { TransferTransaction, TokenId, PrivateKey } = require("@hashgraph/sdk");
const { client } = require("./hederaClient");
require("dotenv").config();
const pools = {};
const PLATFORM_FEE = Big(0.003);
function getAmountOut(dx, reserveIn, reserveOut, feeFraction = PLATFORM_FEE) {
  const dxBig = Big(dx);
  const feeMult = Big(1).minus(feeFraction);
  const dxWithFee = dxBig.times(feeMult);
  const numerator = dxWithFee.times(reserveOut);
  const denominator = Big(reserveIn).plus(dxWithFee);
  return numerator.div(denominator);
}
function createPool(poolId, tokenAId, tokenBId, reserveA, reserveB) {
  pools[poolId] = { tokenAId, tokenBId, reserveA: Big(reserveA), reserveB: Big(reserveB) };
  return pools[poolId];
}
async function executeSwap(poolId, fromTokenId, toTokenId, amountIn, userAccountId) {
  const pool = pools[poolId];
  if (!pool) throw new Error("Pool not found");
  let reserveIn = pool.reserveA, reserveOut = pool.reserveB;
  const dx = Big(amountIn);
  const dy = getAmountOut(dx, reserveIn, reserveOut);
  pool.reserveA = pool.reserveA.plus(dx);
  pool.reserveB = pool.reserveB.minus(dy);
  const operatorId = process.env.HEDERA_ACCOUNT_ID;
  const operatorKey = PrivateKey.fromString(process.env.HEDERA_PRIVATE_KEY);
  const tx = new TransferTransaction()
    .addTokenTransfer(TokenId.fromString(fromTokenId), userAccountId, -dx.toNumber())
    .addTokenTransfer(TokenId.fromString(fromTokenId), operatorId, dx.toNumber())
    .addTokenTransfer(TokenId.fromString(toTokenId), operatorId, -dy.toNumber())
    .addTokenTransfer(TokenId.fromString(toTokenId), userAccountId, dy.toNumber())
    .setTransactionMemo("swap");
  const signed = await tx.freezeWith(client).sign(operatorKey);
  const resp = await signed.execute(client);
  return { receipt: await resp.getReceipt(client), amountOut: dy.toString() };
}
module.exports = { createPool, executeSwap, pools };

# Hackathon Submission Package — Hedera Nexus Agents (Team eTopia)

Included in repo:
- Source scaffolding (frontend, backend, contracts)
- Demo script to simulate A2A exchange
- Docs: architecture, pitch, submission summary
- Smart contract examples (ERC-8004 sample)

How to run demo:
1. Install dependencies: `cd backend && npm ci` and `cd frontend && npm ci`
2. Run backend: `node src/index.js`
3. Run frontend: `cd frontend && npm run dev`
4. Simulate demo: `node backend/demo/run-demo.js`

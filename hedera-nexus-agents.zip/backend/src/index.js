require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { Client, AccountId, PrivateKey, TopicCreateTransaction, TopicMessageSubmitTransaction } = require('@hashgraph/sdk');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const operatorId = process.env.HEDERA_OPERATOR_ID;
const operatorKey = process.env.HEDERA_OPERATOR_KEY;
const network = process.env.HEDERA_NETWORK || 'testnet';

let client = null;
if (operatorId && operatorKey) {
  client = Client.forName(network);
  client.setOperator(AccountId.fromString(operatorId), PrivateKey.fromString(operatorKey));
  console.log('Hedera client initialized for', network);
} else {
  console.log('Hedera keys not set. Running in mock mode.');
}

// Simple endpoints
app.get('/health', (req, res) => res.json({status:'ok'}));

app.post('/agents/register', async (req, res) => {
  const { name, modelType, metadataURI, owner } = req.body;
  // In a full build, deploy ERC-8004 contract or call contract on Hedera EVM
  // For scaffolding, we return a mock agent object
  const agent = { id: owner || '0xmock', name, modelType, metadataURI, reputation:0, createdAt: new Date().toISOString() };
  return res.json({ agent });
});

app.post('/tasks/create', async (req, res) => {
  const { requester, provider, task } = req.body;
  // In full implementation: create HCS topic for negotiation, use HTS for escrow
  // Scaffolding: simulate topic creation and return mock proof
  if (client) {
    try {
      const tx = await new TopicCreateTransaction().execute(client);
      const receipt = await tx.getReceipt(client);
      const topicId = receipt.topicId.toString();
      return res.json({ topicId, proof: `hcs://${topicId}` });
    } catch (err) {
      return res.status(500).json({ error: err.toString() });
    }
  } else {
    return res.json({ topicId: 'demo-topic-1', proof: 'demo-proof-1' });
  }
});

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => console.log('Backend running on port', PORT));

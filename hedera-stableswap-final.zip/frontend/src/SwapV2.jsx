import React from 'react';
import Big from 'big.js';
import { getTokenInfo } from './mirrorApi';
import { BACKEND_API } from './config';
// Build a swap intent: user signs a transfer of tokenA -> TREASURY with memo containing minAmountOut.
// Backend watches Mirror Node for deposits and completes swap by sending tokenB -> user.
export default function SwapV2({ account, tokenA, tokenB }) {
  const [amountHuman, setAmountHuman] = React.useState(''); // human readable (e.g., 10.5)
  const [decimalsA, setDecimalsA] = React.useState(2);
  const [decimalsB, setDecimalsB] = React.useState(2);
  const [slippagePct, setSlippagePct] = React.useState('1.0'); // percent
  const [status, setStatus] = React.useState(null);

  React.useEffect(()=>{
    async function fetchDecimals() {
      try {
        const ta = await getTokenInfo(tokenA);
        const tb = await getTokenInfo(tokenB);
        setDecimalsA(ta.decimals ?? 2);
        setDecimalsB(tb.decimals ?? 2);
      } catch(e){ console.warn('token info fetch failed', e); }
    }
    if (tokenA && tokenB) fetchDecimals();
  },[tokenA, tokenB]);

  function humanToSmallest(amountStr, decimals) {
    const factor = Big(10).pow(decimals);
    return Big(amountStr).times(factor).round(0, 0).toString(); // integer string
  }

  function computeMinOut(estimatedOutHuman) {
    // apply slippage
    const slippage = Big(slippagePct).div(100);
    return Big(estimatedOutHuman).times(Big(1).minus(slippage)).toString();
  }

  async function fetchEstimatedOut(amountHumanStr) {
    // Query backend price estimate endpoint OR compute locally (not available) - we'll call backend for estimate
    try {
      const resp = await fetch(`${BACKEND_API}/estimate?from=${encodeURIComponent(tokenA)}&to=${encodeURIComponent(tokenB)}&amountHuman=${encodeURIComponent(amountHumanStr)}&decimals=${decimalsA}`);
      const js = await resp.json();
      return js.estimatedOutHuman; // backend should return human-readable estimated out
    } catch(e) { console.warn('estimate failed', e); return null; }
  }

  async function doTokenAssociate(tokenId) {
    if (!window.hashconnect) return alert('Wallet not connected');
    try {
      // Build associate request payload according to HashConnect docs
      const associatePayload = {
        topic: window.hashconnect.topic, // may be undefined; wallets often require pairing topic
        metadata: { tokenId }
      };
      // HashConnect provides helper: send a "associate" request through wallet using `request` or `sendTransaction` patterns.
      // We'll use the generic "execute_contract" pattern placeholder as wallets differ. In practice, use hashconnect.accountManager.associateTokens
      alert('Please associate token in your wallet manually if required. (This demo cannot programmatically associate with all wallets.)');
    } catch(e){ console.error(e); alert('Association failed: ' + e.message); }
  }

  async function submitSwapIntent() {
    if (!account) return alert('Connect wallet first');
    if (!amountHuman) return alert('Enter amount');
    setStatus('Building swap intent...');
    // 1) Get estimate from backend
    const est = await fetchEstimatedOut(amountHuman);
    if (!est) { setStatus('Estimate failed'); return; }
    // 2) compute minOut after slippage (human)
    const minOutHuman = computeMinOut(est);
    // 3) convert amount to smallest units
    const amountSmall = humanToSmallest(amountHuman, decimalsA);
    // 4) Attach memo with swap intent details
    const memo = JSON.stringify({ type: 'swap_intent', from: tokenA, to: tokenB, amountInSmall: amountSmall, minOutHuman });
    // 5) Build transfer transaction using HashConnect/send transaction flow
    // For demo: we'll call backend to build a transaction payload the wallet can sign (recommended pattern)
    try {
      const payload = { userAccountId: account, tokenId: tokenA, amount: amountSmall, memo };
      const resp = await fetch(`${BACKEND_API}/build-user-transfer`, { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify(payload) });
      const js = await resp.json();
      if (!js || !js.signedTransactionPayload) {
        setStatus('Backend failed to prepare transfer payload. Check backend.');
        return;
      }
      // Use HashConnect to request the wallet to sign & send the prebuilt transaction bytes
      // Wallet-specific API required; here we demonstrate the intent:
      // window.hashconnect.sendTransaction(signedTx) -- placeholder
      alert('A transfer transaction payload has been prepared by backend. Please sign & submit this transaction using your wallet (HashPack). In production, use HashConnect transaction signing APIs.');
      setStatus('Swap intent submitted. Wait for backend to observe deposit and finalize swap.');
    } catch(e){ console.error(e); setStatus('Swap intent failed: ' + e.message); }
  }

  return (
    <div style={{ padding: 16, border: '1px solid #ddd', borderRadius: 8 }}>
      <h3>Swap (non-custodial intent)</h3>
      <div style={{ marginBottom: 8 }}>
        <label>From token ({tokenA})</label><br/>
        <input placeholder='Amount (human)' value={amountHuman} onChange={e=>setAmountHuman(e.target.value)} />
      </div>
      <div style={{ marginBottom: 8 }}>
        <label>Slippage tolerance (%)</label><br/>
        <input value={slippagePct} onChange={e=>setSlippagePct(e.target.value)} />
      </div>
      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={()=>doTokenAssociate(tokenA)}>Associate Token A</button>
        <button onClick={()=>doTokenAssociate(tokenB)}>Associate Token B</button>
        <button onClick={submitSwapIntent}>Submit Swap Intent (sign transfer)</button>
      </div>
      {status && <div style={{ marginTop: 12, fontSize: 14 }}>{status}</div>}
    </div>
  );
}

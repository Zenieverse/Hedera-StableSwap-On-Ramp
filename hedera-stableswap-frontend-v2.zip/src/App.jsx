import React from 'react';
import Wallet from './WalletConnect.js';
import SwapV2 from './SwapV2.jsx';
import LiquidityChartLive from './LiquidityChartLive.jsx';
export default function App() {
  const [account, setAccount] = React.useState(null);
  const [tokenA, setTokenA] = React.useState('0.0.XXXXX');
  const [tokenB, setTokenB] = React.useState('0.0.YYYYY');
  React.useEffect(()=>{
    // placeholders — replace with your created token IDs
  },[]);
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: 20 }}>
      <h1>Hedera StableSwap On-Ramp — Dashboard (v2)</h1>
      <Wallet onConnect={acct => setAccount(acct)} />
      {account && <p>Connected: {account}</p>}
      <div style={{ display: 'flex', gap: 20, marginTop: 20 }}>
        <div style={{ flex: 1 }}>
          <SwapV2 account={account} tokenA={tokenA} tokenB={tokenB} />
        </div>
        <div style={{ width: 520 }}>
          <LiquidityChartLive tokenA={tokenA} tokenB={tokenB} />
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import Wallet from './WalletConnect.js';
import Swap from './Swap.jsx';
import LiquidityChart from './LiquidityChart.jsx';
export default function App() {
  const [account, setAccount] = React.useState(null);
  const [tokenA, setTokenA] = React.useState(''); // token ids
  const [tokenB, setTokenB] = React.useState('');
  // Example tokens -- replace with your created token IDs
  React.useEffect(()=>{
    setTokenA('0.0.XXXXX'); // USDH token id placeholder
    setTokenB('0.0.YYYYY'); // BASE token id placeholder (HBAR or HTS)
  },[]);
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: 20 }}>
      <h1>Hedera StableSwap On-Ramp — Dashboard</h1>
      <Wallet onConnect={acct => setAccount(acct)} />
      {account && <p>Connected: {account}</p>}
      <div style={{ display: 'flex', gap: 20, marginTop: 20 }}>
        <div style={{ flex: 1 }}>
          <Swap account={account} tokenA={tokenA} tokenB={tokenB} />
        </div>
        <div style={{ width: 480 }}>
          <LiquidityChart tokenA={tokenA} tokenB={tokenB} />
        </div>
      </div>
    </div>
  );
}

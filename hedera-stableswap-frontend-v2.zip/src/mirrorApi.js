import { MIRROR_NODE, TREASURY_ACCOUNT } from './config';
export async function getAccountBalances(accountId) {
  if (!accountId) return null;
  const url = `${MIRROR_NODE}/accounts/${encodeURIComponent(accountId)}/balances`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Mirror Node balances fetch failed');
  return res.json();
}
export async function getTokenInfo(tokenId) {
  const url = `${MIRROR_NODE}/tokens/${encodeURIComponent(tokenId)}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Mirror Node token info fetch failed');
  return res.json();
}
export async function getTreasuryReserves(tokenA, tokenB) {
  // fetch treasury balances and extract token balances for tokenA and tokenB
  const res = await getAccountBalances(TREASURY_ACCOUNT);
  if (!res) return null;
  const tokenBalances = res.tokens || [];
  const findBal = (tid) => {
    const t = tokenBalances.find(x=>x.token_id===tid);
    return t ? Number(t.balance) : 0;
  };
  return { reserveA: findBal(tokenA), reserveB: findBal(tokenB) };
}

import React from 'react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
import { getTreasuryReserves } from './mirrorApi';
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);
export default function LiquidityChartLive({ tokenA, tokenB }) {
  const [series, setSeries] = React.useState({ labels: [], dataA: [], dataB: [] });
  React.useEffect(()=>{
    let mounted = true;
    async function refresh() {
      try {
        const res = await getTreasuryReserves(tokenA, tokenB);
        const now = new Date().toLocaleTimeString();
        setSeries(prev => {
          const labels = [...prev.labels, now].slice(-20);
          const dataA = [...prev.dataA, res ? res.reserveA : 0].slice(-20);
          const dataB = [...prev.dataB, res ? res.reserveB : 0].slice(-20);
          return { labels, dataA, dataB };
        });
      } catch(e){ console.warn(e); }
    }
    refresh();
    const id = setInterval(refresh, 15000);
    return ()=>{ mounted=false; clearInterval(id); };
  },[tokenA, tokenB]);
  const data = {
    labels: series.labels,
    datasets: [
      { label: 'Reserve A', data: series.dataA, tension: 0.4 },
      { label: 'Reserve B', data: series.dataB, tension: 0.4 }
    ]
  };
  return (
    <div style={{ padding: 16, border: '1px solid #eee', borderRadius: 8 }}>
      <h3>Liquidity (live)</h3>
      <Line data={data} />
      <div style={{ fontSize: 12, marginTop: 8 }}>Tokens: {tokenA} / {tokenB}</div>
    </div>
  );
}

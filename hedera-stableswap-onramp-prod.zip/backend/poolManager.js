const Big = require("big.js");
const { TransferTransaction, TokenId, PrivateKey } = require("@hashgraph/sdk");
const { client } = require("./hederaClient");
require("dotenv").config();
const pools = {};
const PLATFORM_FEE = Big(0.003);
function getAmountOut(dx, reserveIn, reserveOut, feeFraction = PLATFORM_FEE) {
  const dxBig = Big(dx);
  const feeMult = Big(1).minus(feeFraction);
  const dxWithFee = dxBig.times(feeMult);
  const numerator = dxWithFee.times(reserveOut);
  const denominator = Big(reserveIn).plus(dxWithFee);
  const dy = numerator.div(denominator);
  return dy;
}
function createPool(poolId, tokenAId, tokenBId, reserveA, reserveB) {
  pools[poolId] = { tokenAId, tokenBId, reserveA: reserveA, reserveB: reserveB };
  return pools[poolId];
}
async function executeSwap(poolId, fromTokenId, toTokenId, amountIn, userAccountId) {
  const pool = pools[poolId];
  if (!pool) throw new Error("Pool not found");
  let reserveIn = Big(pool.reserveA), reserveOut = Big(pool.reserveB);
  let isAtoB = true;
  if (fromTokenId === pool.tokenAId && toTokenId === pool.tokenBId) {
    isAtoB = true;
  } else if (fromTokenId === pool.tokenBId && toTokenId === pool.tokenAId) {
    isAtoB = false;
    reserveIn = Big(pool.reserveB);
    reserveOut = Big(pool.reserveA);
  } else {
    throw new Error("Token mismatch for pool");
  }
  const dx = Big(amountIn);
  const dy = getAmountOut(dx, reserveIn, reserveOut);
  // update reserves (strings/numbers)
  if (isAtoB) {
    pool.reserveA = Big(pool.reserveA).plus(dx).toString();
    pool.reserveB = Big(pool.reserveB).minus(dy).toString();
  } else {
    pool.reserveB = Big(pool.reserveB).plus(dx).toString();
    pool.reserveA = Big(pool.reserveA).minus(dy).toString();
  }
  // perform HTS transfers via Hedera SDK (operator moves tokens between custodied accounts)
  const operatorId = process.env.HEDERA_ACCOUNT_ID;
  const operatorKey = PrivateKey.fromString(process.env.HEDERA_PRIVATE_KEY);
  const transferTx = new TransferTransaction()
    .addTokenTransfer(TokenId.fromString(fromTokenId), userAccountId, -Number(amountIn))
    .addTokenTransfer(TokenId.fromString(fromTokenId), operatorId, Number(amountIn))
    .addTokenTransfer(TokenId.fromString(toTokenId), operatorId, -Number(dy.toString()))
    .addTokenTransfer(TokenId.fromString(toTokenId), userAccountId, Number(dy.toString()))
    .setTransactionMemo(`swap ${fromTokenId} -> ${toTokenId}`);
  const signed = await transferTx.freezeWith(client).sign(operatorKey);
  const resp = await signed.execute(client);
  const receipt = await resp.getReceipt(client);
  return { receipt, amountOut: dy.toString() };
}
module.exports = { createPool, executeSwap, getAmountOut, pools };

const Big = require('big.js');
const { TransferTransaction, TokenId, PrivateKey } = require('@hashgraph/sdk');
const { client } = require('./hederaClient');
require('dotenv').config();
const pools = {};
function createPool(poolId, tokenAId, tokenBId, reserveA, reserveB){ pools[poolId] = { tokenAId, tokenBId, reserveA: reserveA, reserveB: reserveB }; return pools[poolId]; }
function getAmountOut(dx, reserveIn, reserveOut){ const x = Big(dx); const rx = Big(reserveIn); const ry = Big(reserveOut); const fee = Big(0.003); const dxWithFee = x.times(Big(1).minus(fee)); const numerator = dxWithFee.times(ry); const denominator = rx.plus(dxWithFee); return numerator.div(denominator); }
async function executeSwap(poolId, fromTokenId, toTokenId, amountIn, userAccountId){ const pool = pools[poolId]; if(!pool) throw new Error('pool not found'); // naive update and no HTS ops in this minimal ship
  const dy = getAmountOut(amountIn, pool.reserveA, pool.reserveB); pool.reserveA = Number(pool.reserveA) + Number(amountIn); pool.reserveB = Number(pool.reserveB) - Number(dy); return { amountOut: dy.toString() }; }
module.exports = { createPool, executeSwap, getAmountOut, pools };

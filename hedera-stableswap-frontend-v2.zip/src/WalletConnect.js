import React from 'react';
import HashConnect from 'hashconnect';
// This component implements HashConnect pairing and provides the `hashconnect` instance to children via window.hashconnect.
export default function Wallet({ onConnect }) {
  const [connected, setConnected] = React.useState(false);
  const [account, setAccount] = React.useState(null);
  const hcRef = React.useRef(null);
  React.useEffect(()=>{
    hcRef.current = new HashConnect.HashConnect();
    const init = async ()=>{
      const appMeta = { name: "Hedera StableSwap Demo", description: "Demo app", icon: "" };
      const state = await hcRef.current.init(appMeta);
      // Save pairing data to window for other modules
      window.hashconnect = hcRef.current;
      window.hashconnectState = state;
    };
    init();
  },[]);
  const connect = async ()=>{
    try {
      // Request pairing; the wallet will show pairing UI (HashPack users)
      const topic = await hcRef.current.connect();
      // request account(s)
      const pairingData = await hcRef.current.pair(topic); // may open wallet
      const accounts = pairingData.accountIds;
      const acc = accounts?.[0] || null;
      setAccount(acc);
      setConnected(!!acc);
      if (acc && onConnect) onConnect(acc);
    } catch(e){ console.error(e); alert('HashConnect pairing failed - ensure HashPack is installed'); }
  };
  return (
    <div>
      <button onClick={connect}>{connected ? 'Connected' : 'Connect Wallet (HashPack)'}</button>
      {account && <div style={{ marginTop: 8 }}>Account: {account}</div>}
    </div>
  );
}

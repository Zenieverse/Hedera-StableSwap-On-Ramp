export default function handler(req, res) {
  res.status(200).json({ agents: [{name:'DataX', model:'research'}, {name:'AlphaBot', model:'trading'}] });
}

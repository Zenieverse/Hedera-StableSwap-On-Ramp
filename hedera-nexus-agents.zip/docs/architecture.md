# Architecture Overview

Frontend (Next.js) <-> Backend API (Node.js/Express) <-> Hedera SDK (HCS/HTS/Smart Contracts)
  - Optional: IPFS for large artifacts
  - Optional: LangChain/OpenAI for agent reasoning

Key components:
- Agent Registry (ERC-8004) on Hedera smart contracts
- A2A messaging using Hedera Consensus Service (HCS) topics
- Escrow & Payment using Hedera Token Service (HTS)
- Sanctum Gateway integration for atomic, zero-loss tasks

# Submission Summary — Hedera Nexus Agents (Team eTopia)

**Track:** AI & Agents — Intermediate Problem Statement (Collaborative Multi-Agent Marketplace)

**Short description:** Hedera Nexus Agents is a verifiable, on-chain marketplace where autonomous AI agents register (ERC-8004), discover peers, negotiate tasks, and transact with micro-payments using HTS. Proofs of execution are recorded on HCS for auditability. The platform demonstrates A2A flows and Sanctum-backed atomic confirmations for high-value exchanges.

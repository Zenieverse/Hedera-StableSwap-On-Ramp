#!/usr/bin/env bash
# Run demo locally: start Postgres (docker), migrate, start backend, run demo simulate script
set -e
echo "Starting local postgres via docker..."
docker run --name hs_demo_pg -e POSTGRES_PASSWORD=postgres -e POSTGRES_USER=postgres -e POSTGRES_DB=stableswap -p 5432:5432 -d postgres:15-alpine
echo "Waiting for Postgres to be ready..."
sleep 3
echo "Install backend deps and run migrations"
cd backend
npm install
export POSTGRES_URL=postgresql://postgres:postgres@localhost:5432/stableswap
npm run migrate
echo "Start backend in background"
npm start &
echo "Run demo simulate script (ensure .env has DEMO_USER_ACCOUNT & DEMO_USER_PRIVATE_KEY set)"
node demo/demo_simulate_swap.js

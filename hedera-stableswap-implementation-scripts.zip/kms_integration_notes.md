KMS Integration Notes (AWS and GCP)
----------------------------------
Do NOT store private keys in plain text. Use a KMS to protect signing keys.

AWS KMS (recommended pattern):
1. Create a Customer Master Key (CMK) in AWS KMS.
2. Grant Render IAM role or deployment user permission to use the key.
3. Store the Hedera private key as a secret in AWS Secrets Manager or as an encrypted blob in SSM Parameter Store.
4. In your app, use AWS SDK to fetch the secret at runtime and use KMS to decrypt if necessary.
5. Consider using AWS CloudHSM for hardware-backed key material if you need signing in HSM.

GCP KMS:
1. Store the token or encrypted secret in Secret Manager.
2. Ensure the service account used by Render (or your deploy pipeline) has permissions to access Secret Manager.
3. Fetch the secret at runtime.

Alternative (recommended): Use a signing service (Hashicorp Vault or a dedicated HSM-based signing microservice). The app sends unsigned bytes to the signing service, the signing service returns signed transaction bytes (this avoids storing raw private key in app memory).

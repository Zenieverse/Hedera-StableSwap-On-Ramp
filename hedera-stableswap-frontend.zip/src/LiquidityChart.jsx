import React from 'react';
import { Line } from 'react-chartjs-2';
import { Chart as ChartJS, CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend } from 'chart.js';
ChartJS.register(CategoryScale, LinearScale, PointElement, LineElement, Title, Tooltip, Legend);
// Placeholder chart showing reserves over time (demo)
export default function LiquidityChart({ tokenA, tokenB }) {
  const [data, setData] = React.useState({
    labels: ['t-4','t-3','t-2','t-1','now'],
    datasets: [
      { label: 'Reserve A', data: [1000,1200,900,1100,1050], tension: 0.4 },
      { label: 'Reserve B', data: [500,450,480,470,490], tension: 0.4 }
    ]
  });
  return (
    <div style={{ padding: 16, border: '1px solid #eee', borderRadius: 8 }}>
      <h3>Liquidity (sample)</h3>
      <Line data={data} />
      <div style={{ fontSize: 12, marginTop: 8 }}>Tokens: {tokenA} / {tokenB}</div>
    </div>
  );
}

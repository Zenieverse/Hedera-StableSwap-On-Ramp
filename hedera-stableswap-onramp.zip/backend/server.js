const express = require("express");
const bodyParser = require("body-parser");
const { createStableToken, mintStableToken } = require("./stableToken");
const { createPool, executeSwap } = require("./poolManager");
const { createHCSTopicIfMissing, client } = require("./hederaClient");
const { TopicMessageSubmitTransaction } = require("@hashgraph/sdk");
require("dotenv").config();
const app = express();
app.use(bodyParser.json());
let poolCounter = 0;
let topicId = process.env.HCS_TOPIC_ID;
async function logEvent(obj) {
  if (!topicId) topicId = await createHCSTopicIfMissing();
  const tx = new TopicMessageSubmitTransaction({ topicId, message: JSON.stringify(obj) });
  await tx.execute(client);
}
app.post("/create-stable", async (req, res) => {
  try {
    const tokenId = await createStableToken(req.body);
    await logEvent({ type: "create-stable", tokenId });
    res.json({ tokenId });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post("/mint", async (req, res) => {
  try {
    const receipt = await mintStableToken(req.body.tokenId, req.body.amount);
    await logEvent({ type: "mint", ...req.body });
    res.json({ receipt });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post("/create-pool", async (req, res) => {
  try {
    const poolId = "pool-" + (++poolCounter);
    createPool(poolId, req.body.tokenAId, req.body.tokenBId, req.body.reserveA, req.body.reserveB);
    await logEvent({ type: "create-pool", poolId });
    res.json({ poolId });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.post("/swap", async (req, res) => {
  try {
    const result = await executeSwap(req.body.poolId, req.body.fromTokenId, req.body.toTokenId, req.body.amountIn, req.body.userAccountId);
    await logEvent({ type: "swap", ...req.body, amountOut: result.amountOut });
    res.json({ result });
  } catch (e) { res.status(500).json({ error: e.message }); }
});
app.listen(3000, () => console.log("Hedera StableSwap API on 3000"));

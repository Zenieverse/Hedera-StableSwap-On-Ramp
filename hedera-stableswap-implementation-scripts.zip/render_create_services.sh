  #!/usr/bin/env bash
  # Use Render CLI to create services from render.yaml or trigger redeploy.
  # Prereqs: render CLI installed and RENDER_API_KEY env var set.
  set -e
  if [ -z "$RENDER_API_KEY" ]; then echo "Please export RENDER_API_KEY before running"; exit 1; fi
  echo "If you haven't already connected this GitHub repo to Render, do so in the Render dashboard and import render.yaml."
  echo "This script will attempt to trigger redeploy for the Render services set in render.yaml using render CLI if available."
  if command -v render >/dev/null 2>&1; then
    echo "Render CLI found. To redeploy a service, run:
render services list --api-key $RENDER_API_KEY
render services redeploy <SERVICE_ID> --api-key $RENDER_API_KEY"
  else
    echo "Render CLI not found. Install it: https://render.com/docs/cli"
  fi

import React from 'react';
import { BACKEND_API } from './config';
export default function Swap({ account, tokenA, tokenB }) {
  const [amountIn, setAmountIn] = React.useState('');
  const [swapping, setSwapping] = React.useState(false);
  const [result, setResult] = React.useState(null);
  const doSwap = async () => {
    if (!account) return alert('Connect wallet first');
    setSwapping(true);
    try {
      const payload = {
        poolId: 'pool-1', // adjust as needed
        fromTokenId: tokenA,
        toTokenId: tokenB,
        amountIn: amountIn,
        userAccountId: account
      };
      const resp = await fetch(`${BACKEND_API}/swap`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await resp.json();
      setResult(data);
    } catch (e) { console.error(e); alert('Swap failed: ' + e.message); }
    setSwapping(false);
  };
  return (
    <div style={{ padding: 16, border: '1px solid #ddd', borderRadius: 8 }}>
      <h3>Swap</h3>
      <div>
        <label>From (tokenId):</label>
        <div style={{ fontSize: 12 }}>{tokenA}</div>
      </div>
      <div style={{ marginTop: 8 }}>
        <label>To (tokenId):</label>
        <div style={{ fontSize: 12 }}>{tokenB}</div>
      </div>
      <div style={{ marginTop: 12 }}>
        <input placeholder='Amount in smallest units' value={amountIn} onChange={e=>setAmountIn(e.target.value)} />
        <button onClick={doSwap} disabled={swapping} style={{ marginLeft: 8 }}>{swapping? 'Swapping...': 'Swap'}</button>
      </div>
      {result && <pre style={{ marginTop: 12, background: '#f7f7f7', padding: 8 }}>{JSON.stringify(result,null,2)}</pre>}
    </div>
  );
}

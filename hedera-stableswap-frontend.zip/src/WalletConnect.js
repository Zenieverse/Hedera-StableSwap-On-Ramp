import React from 'react';
import { HashConnect } from 'hashconnect';
// Simple HashConnect integration (HashPack)
export default function Wallet({ onConnect }) {
  const [connected, setConnected] = React.useState(false);
  const [account, setAccount] = React.useState(null);
  const hcRef = React.useRef(null);
  React.useEffect(()=>{
    hcRef.current = new HashConnect();
    // initialize - app metadata minimal
    const init = async ()=>{
      const appMeta = {
        name: "Hedera StableSwap Demo",
        description: "Demo app for swaps & on-ramp",
        icon: ""
      };
      const state = await hcRef.current.init(appMeta);
      // create pairing string and open wallet - in production present QR / deep link
      // We'll rely on HashPack users to accept pairing via their wallet UI
    };
    init();
  },[]);
  const connect = async ()=>{
    try {
      const res = await hcRef.current.connect();
      // res: { accountIds, topic, pairedWallets }
      const acc = res?.accountIds?.[0] || null;
      setAccount(acc);
      setConnected(!!acc);
      if (acc && onConnect) onConnect(acc);
    } catch(e){ console.error(e); alert('HashConnect pairing failed - ensure HashPack is installed'); }
  };
  return (
    <div>
      <button onClick={connect}>{connected ? 'Connected' : 'Connect Wallet (HashPack)'}</button>
      {account && <div style={{ marginTop: 8 }}>Account: {account}</div>}
    </div>
  );
}

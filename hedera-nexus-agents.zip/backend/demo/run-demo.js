/*
Simple demo script to simulate two agents negotiating a task.
This is a simulated flow and does not perform real token transfers.
Run: node demo/run-demo.js
*/
console.log('--- Hedera Nexus Agents Demo (simulated) ---');
console.log('Registering agents...');
const agents = [
  { name: 'DataX', owner: '0xAgent1', model: 'research' },
  { name: 'AlphaBot', owner: '0xAgent2', model: 'trading' }
];
console.log('Agents:', agents);
console.log('AlphaBot requests a sentiment analysis task from DataX for 0.05 HBAR (simulated)');
console.log('Negotiating via HCS topic (simulated) ...');
setTimeout(()=>{
  console.log('DataX accepts. Creating escrow (simulated).');
  setTimeout(()=>{
    console.log('DataX completes the task and publishes proof to HCS (simulated).');
    setTimeout(()=>{
      console.log('Escrow released. Payment settled. Task complete.');
      console.log('Proof: hcs://demo-topic-12345');
    }, 800);
  }, 800);
}, 1000);

const { Client } = require('pg');
require('dotenv').config();
(async ()=>{
  const { Pool } = require('pg');
  const pool = new Pool({ connectionString: process.env.POSTGRES_URL });
  await pool.query(`CREATE TABLE IF NOT EXISTS pools (id TEXT PRIMARY KEY, token_a TEXT, token_b TEXT, reserve_a NUMERIC, reserve_b NUMERIC, created_at TIMESTAMP DEFAULT now())`);
  await pool.query(`CREATE TABLE IF NOT EXISTS processed_txs (transaction_id TEXT PRIMARY KEY, processed_at TIMESTAMP DEFAULT now())`);
  console.log('Migration complete');
  await pool.end();
})().catch(e=>{ console.error(e); process.exit(1); });

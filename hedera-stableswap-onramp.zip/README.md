# Hedera StableSwap On-Ramp

A demo decentralized app for **fiat on/off-ramp** and **HTS stable token swaps** with **HCS settlement logs**.

## Features
- Mint fiat-backed HTS stable tokens
- Execute swaps via backend AMM (constant-product)
- Log every transaction on HCS for audit trail
- Monitor liquidity via Mirror Node

## Run
1. `cd backend && npm install`
2. `cp .env.example .env`
3. Fill Hedera testnet credentials
4. `npm start`

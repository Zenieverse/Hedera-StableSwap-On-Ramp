#!/usr/bin/env bash
# ONE-CLICK ORCHESTRATOR for Hedera StableSwap On-Ramp
# This script automates (locally) the common setup steps:
# 1) Initialize git repo and push to GitHub via gh CLI (requires gh auth)
# 2) Set GitHub secrets via gh CLI
# 3) Trigger Render deploy via Render API or CLI (requires RENDER_API_KEY)
# 4) Optionally run local demo (starts Postgres docker, runs migrations, starts backend, runs demo simulate script)
#
# WARNING: This script will prompt for sensitive values (private keys). Do not run on shared machines.
set -e
echo "=== Hedera StableSwap One-Click Orchestrator ==="

# Check prerequisites
for cmd in git gh curl docker npm; do
  if ! command -v $cmd >/dev/null 2>&1; then
    echo "Missing required command: $cmd. Please install it and re-run."
    exit 1
  fi
done

read -p "GitHub repo name to create (owner/repo or repo): " REPO_NAME
if [ -z "$REPO_NAME" ]; then echo "Repo name required"; exit 1; fi
read -p "Make GitHub repo public or private? (public/private) [private]: " GH_VIS; GH_VIS=${GH_VIS:-private}

# Initialize git if needed
if [ ! -d .git ]; then
  git init
  git add .
  git commit -m "Initial commit - Hedera StableSwap" || true
fi

# Create GitHub repo via gh
echo "Creating GitHub repo..."
gh repo create "$REPO_NAME" --$GH_VIS --source=. --remote=origin --push || true

# Prompt for secrets (will be set with gh secret set)
echo "Now we'll set GitHub repository secrets. These will be stored in your repo's Secrets."
read -p "Enter POSTGRES_URL (e.g. postgresql://postgres:postgres@host:5432/stableswap): " POSTGRES_URL
read -p "Enter RENDER_API_KEY (for Render deploy; optional, press enter to skip): " RENDER_API_KEY
read -p "Enter RENDER_SERVICE_ID (optional): " RENDER_SERVICE_ID
read -p "Enter HEDERA_ACCOUNT_ID (testnet): " HEDERA_ACCOUNT_ID
read -s -p "Enter HEDERA_PRIVATE_KEY (paste, will be hidden): " HEDERA_PRIVATE_KEY; echo
read -p "Enter TREASURY_ACCOUNT (0.0.x): " TREASURY_ACCOUNT

echo "Setting GitHub repo secrets..."
gh secret set POSTGRES_URL --repo "$REPO_NAME" --body "$POSTGRES_URL"
if [ -n "$RENDER_API_KEY" ]; then gh secret set RENDER_API_KEY --repo "$REPO_NAME" --body "$RENDER_API_KEY"; fi
if [ -n "$RENDER_SERVICE_ID" ]; then gh secret set RENDER_SERVICE_ID --repo "$REPO_NAME" --body "$RENDER_SERVICE_ID"; fi
gh secret set HEDERA_ACCOUNT_ID --repo "$REPO_NAME" --body "$HEDERA_ACCOUNT_ID"
gh secret set HEDERA_PRIVATE_KEY --repo "$REPO_NAME" --body "$HEDERA_PRIVATE_KEY"
gh secret set TREASURY_ACCOUNT --repo "$REPO_NAME" --body "$TREASURY_ACCOUNT"

echo "GitHub repo ready. Pushed to origin."

if [ -n "$RENDER_API_KEY" ] && [ -n "$RENDER_SERVICE_ID" ]; then
  echo "Triggering Render deploy via API..."
  curl -X POST "https://api.render.com/v1/services/$RENDER_SERVICE_ID/deploys" -H "Authorization: Bearer $RENDER_API_KEY" -H "Content-Type: application/json" -d '{"clearCache":true}'
  echo "Deploy triggered."
else
  echo "Skipping Render deploy (no API key or service id provided)."
fi

read -p "Do you want to run local demo now? This will start a Postgres docker container and run the demo. (y/N): " RUN_DEMO
if [[ "$RUN_DEMO" =~ ^[Yy]$ ]]; then
  echo "Starting local demo..."
  ./run_demo_locally.sh
else
  echo "Demo skipped. You can run ./run_demo_locally.sh later."
fi

echo "All done. Monitor GitHub Actions for CI, and Render dashboard for deploy status."

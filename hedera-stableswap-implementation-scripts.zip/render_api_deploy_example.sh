  #!/usr/bin/env bash
  # Example of calling Render REST API to trigger deploy for a service.
  # Requires RENDER_API_KEY and RENDER_SERVICE_ID env vars.
  set -e
  if [ -z "$RENDER_API_KEY" ] || [ -z "$RENDER_SERVICE_ID" ]; then echo "Set RENDER_API_KEY and RENDER_SERVICE_ID"; exit 1; fi
  echo "Triggering deploy for service $RENDER_SERVICE_ID via Render API"
  curl -X POST "https://api.render.com/v1/services/$RENDER_SERVICE_ID/deploys" \
-H "Authorization: Bearer $RENDER_API_KEY" \
-H "Content-Type: application/json" \
-d '{"clearCache":true}'

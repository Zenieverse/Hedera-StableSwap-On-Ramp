const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');
const winston = require('winston');
const fetch = require('node-fetch');
const { createStableToken, mintStableToken } = require('./stableToken');
const { createPool, executeSwap, getAmountOut, pools } = require('./poolManager');
const { createHCSTopicIfMissing, client } = require('./hederaClient');
const { TopicMessageSubmitTransaction, TransferTransaction, TokenId, PrivateKey } = require('@hashgraph/sdk');
require('dotenv').config();
const app = express();
app.use(bodyParser.json());
const logger = winston.createLogger({ transports: [new winston.transports.Console()] });
const PORT = process.env.PORT || 3000;
const POSTGRES_URL = process.env.POSTGRES_URL;
const TREASURY = process.env.TREASURY_ACCOUNT;
const MIRROR_NODE = process.env.MIRROR_NODE || 'https://testnet.mirrornode.hedera.com/api/v1';
const pg = new Pool({ connectionString: POSTGRES_URL });
app.get('/health', (req,res)=> res.json({ ok: true }));
// reuse previous endpoints: create-stable, mint, create-pool, estimate, build-user-transfer, swap, fiat-webhook
// For brevity, import endpoints from modular files if present else provide minimal placeholders.
app.get('/', (req,res)=> res.json({ service: 'hedera-stableswap-backend', env: process.env.NODE_ENV || 'production' }));
// Start watcher if RUN_WATCHER=true (Render worker pattern: run backend with RUN_WATCHER=false, and a separate service for watcher)
if (process.env.RUN_WATCHER === 'true') {
  logger.info('Starting Mirror Node watcher (worker)');
  const POLL_INTERVAL = Number(process.env.WATCHER_POLL_MS || 8000);
  let lastPoll = Date.now() - 60*1000;
  const processed = new Set();
  async function poll(){ 
    try {
      if (!TREASURY) { logger.warn('TREASURY_ACCOUNT not configured - watcher idle'); return; }
      const url = `${MIRROR_NODE}/transactions?account.id=${encodeURIComponent(TREASURY)}&order=desc&limit=25`;
      const resp = await fetch(url);
      if (!resp.ok) { logger.warn('Mirror node fetch failed', resp.status); return; }
      const js = await resp.json();
      for (const tx of js.transactions || []){
        if (processed.has(tx.transaction_id)) continue;
        // basic processing demonstration: log tx ids
        logger.info('Observed tx', tx.transaction_id);
        processed.add(tx.transaction_id);
      }
    } catch(e){ logger.error('Watcher error', e.message); }
  }
  setInterval(poll, POLL_INTERVAL);
}
app.listen(PORT, ()=> { console.log(`Server listening on ${PORT}`); });
module.exports = app;

// Configure API endpoint for backend (change as needed)
export const BACKEND_API = process.env.BACKEND_API || "http://localhost:3000";
// Mirror Node base (testnet)
export const MIRROR_NODE = "https://testnet.mirrornode.hedera.com/api/v1";

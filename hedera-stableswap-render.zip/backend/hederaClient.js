const { Client, PrivateKey, TopicCreateTransaction } = require('@hashgraph/sdk');
require('dotenv').config();
const operatorId = process.env.HEDERA_ACCOUNT_ID;
const operatorKey = process.env.HEDERA_PRIVATE_KEY;
const network = process.env.NETWORK || 'testnet';
if (!operatorId || !operatorKey) { console.warn('HEDERA_ACCOUNT_ID or PRIVATE_KEY not set'); }
const client = Client.forName(network);
if (operatorId && operatorKey) client.setOperator(operatorId, operatorKey);
async function createHCSTopicIfMissing(){ if (process.env.HCS_TOPIC_ID) return process.env.HCS_TOPIC_ID; const tx = await new TopicCreateTransaction().execute(client); const r = await tx.getReceipt(client); return r.topicId.toString(); }
module.exports = { client, createHCSTopicIfMissing };
